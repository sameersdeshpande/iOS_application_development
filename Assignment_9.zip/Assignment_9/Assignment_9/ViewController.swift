//
//  ViewController.swift
//  Assignment_7
//
//  Created by Sameer Shashikant Deshpande on 10/22/24.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
    }
}

