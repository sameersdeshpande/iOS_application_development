//
//  Assignment_10App.swift
//  Assignment_10
//
//  Created by Sameer Shashikant Deshpande on 11/15/24.
//

import SwiftUI

@main
struct Assignment_10App: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
